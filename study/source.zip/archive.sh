#!/bin/bash
zip -r source.zip archive.sh ecec357.html index.html jquery-ui-1.10.2.custom
